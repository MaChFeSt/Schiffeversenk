	
   ______   ______  ________  ________ __     ______     _____   __  _____     ______  ________ ______        ____  __    __  __  _____     ____
  |   _  \ /  __  \|__    __||__    __|  |   |   ___|   |   _  \|  ||   _  \  /  __  \|__    __|   ___|     /  ___||  |  |  ||  ||   _  \ /  ___|
  |  |__\ |  /__\  |  |  |      |  |  |  |   |  |___    |  |_\  |  ||  |_\  ||  /__\  |  |  |  |  |___     |  <___ |  |__|  ||  ||  |_\  |  <___
  |   _  <|   __   |  |  |      |  |  |  |   |   ___|   |   ___/|  ||      / |   __   |  |  |  |   ___|     \___  \|   __   ||  ||   ___/ \___  \
  |  |__\ |  |  |  |  |  |      |  |  |  |___|  |___    |  |    |  ||  |\  \ |  |  |  |  |  |  |  |___      ____>  |  |  |  ||  ||  |     ____>  |
  |______/|__|  |__|  |__|      |__|  |______|______|   |__|    |__||__| \__\|__|  |__|  |__|  |______|    |______/|__|  |__||__||__|    |______/



---

# READ ME  


## BATTLE PIRATE SHIPS early access v.0.42  


## BESCHREIBUNG	  

Battle Pirate Ships ist ein klassisches Schiffeversenken Spiel, dass dem Spieler erlaubt,  
auf einen Spielfeld der Gr��en 5x5 bis 30x30 einen Computer oder auch einen anderen  
Spieler im Multiplayer herauszufordern.

## INSTALLATION

Um die Datei auszuf�hren, ben�tigt ihr die Software Java Runtime Enviroment.  
Einen Link zum herunterladen, findet man auf folgender Seite:  

```bash
[https://java.com/de/download/] (https://java.com/de/download/)  
���  

Ist Java erfolgreich installiert, reicht ein Doppelklick auf die BattlePirateShips datei  
um das Spiel zu starten.

## KNOWN ISSUES

	* Das Netzwerk-Spiel geht leider im Moment nur bis zum Spielstart. Dannach gibt es  
	  noch einige Probleme mit der Kommunikation zwischen Host und Client. 
	  Den Code dazu finden Sie in Host.java und Client.java

	* Beim Laden des Spiels kann es sein, dass sich die AI aufh�ngt. Manchmal sofort,  
	  manchmal erst nach ein paar Z�gen. Dann kann das Spiel leider nicht fortgef�hrt werden.  

	* Es kann vorkommen, dass die eigenen Z�ge nicht korrekt angezeigt werden. In diesem Fall  
	  kann man das Spiel speichern und neu laden und hoffen, dass oben genannter Bug nicht  		
	  auftritt.

## SPIELSTART

Kurzfassung:  
Im Men� kann man ausw�hlen, welchen Spielmodus man w�hlen m�chte. Wir empfehlen, den VersusAI  
Modus auszuw�hlen. 
Als erstes wird man aufgefordert, die Spielfeldgr��e anzugeben. Mit Enter und Confirm kann man dann  
seine Schiffe setzen und das Spiel starten.
Ab diesem Zeitpunkt darf nun immer abwechselnd der Spieler und der Gegner/Ai einmal schie�en.  
Dazu einfach ein Feld auf dem rechten Spielfeld anklicken, sobald oben MY TURN steht.
Man darf einen weiteren Schuss abfeuern, falls man ein Schiff des Gegners getroffen hat.
Am Ende erscheint eine Anzeige, die den Spielausgang angibt.

Viel Spa� beim Spielen :)

F�r eine ausf�hliche Beschreibung bitte in das beigelegte Benutzerhandbuch schauen.

## AUTOREN

Dieses Spiel wurde erstellt von Feyzanur, Christian, Marcus und Stefanie.

